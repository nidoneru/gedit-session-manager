# Session Manager

A plugin for saving and restoring sessions in gedit.

It automatically restores the files that were open before gedit was closed, and also lets you save and manage multiple named sessions.

Designed for **gedit 48.2 and later**. Tested on **gedit 51**.

## Features

- Automatically restores previously open files.
- Saves the currently open files as a named session.
- Updates an existing saved session.
- Restores, renames, and deletes saved sessions.
- Restores the order of files saved in a session.
- Restores sessions directly from the gedit menu.
- Opens the session management dialog with **Ctrl+R**.
- Supports English and Japanese.

## Installation

This release is intended for the **Flatpak version of gedit**.

Copy these two files to:

`~/.var/app/org.gnome.gedit/data/gedit/plugins/`

- `libsessionmanager.so`
- `sessionmanager.plugin`

Restart gedit and enable **Session Manager** from the plugin list.

## Session data

Session data is stored in:

`~/.var/app/org.gnome.gedit/data/gedit/plugins/sessionmanager/saved-sessions.xml`

## License

This project is released under the MIT License. See LICENSE for details.
